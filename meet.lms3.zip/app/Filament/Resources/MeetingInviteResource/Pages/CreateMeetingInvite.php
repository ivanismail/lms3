<?php

namespace App\Filament\Resources\MeetingInviteResource\Pages;

use App\Filament\Resources\MeetingInviteResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMeetingInvite extends CreateRecord
{
    protected static string $resource = MeetingInviteResource::class;
}
