<?php

namespace App\Filament\Resources\MeetingInviteResource\Pages;

use App\Filament\Resources\MeetingInviteResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewMeetingInvite extends ViewRecord
{
    protected static string $resource = MeetingInviteResource::class;
}
